# Alien Shooter Game
A simple game made with Python programming language and using PyGame module for learning purpose by following codes and instructions of a book.
This game is made by following code based insturctions of a book named "Python Crash Course: A Hands-on, Project-based    Introduction to Programming" by Eric Matthes.
This game is made for only learning and educational purpose and for fair use.

# Book Information:
Title	Python Crash Course: A Hands-On, Project-Based Introduction to Programming
Author:	Eric Matthes
Publisher:	No Starch Press, 2015
ISBN:	1593277393, 9781593277390
Length:	560 pages


Thanks to Eric Matthes for writing a very wonderful book to learn Python!



# Screenshots

![alt text](https://github.com/skinan/Alien_Shooter_Game/blob/master/Screenshot/Screenshot%20(62).png "Main Window")

![alt text](https://github.com/skinan/Alien_Shooter_Game/blob/master/Screenshot/Screenshot%20(64).png "Running Window")
